create
    definer = root@`%` procedure sp_emplist(IN _id int unsigned)
BEGIN
	select * from Emp where id < ifnull(_id, 0);
END;

