create definer = root@`%` trigger Subject_AFTER_INSERT
    after insert
    on Subject
    for each row
BEGIN
	update Prof set sujectcnt = subjectcnt + 1
     where id = New.Prof;
END;

