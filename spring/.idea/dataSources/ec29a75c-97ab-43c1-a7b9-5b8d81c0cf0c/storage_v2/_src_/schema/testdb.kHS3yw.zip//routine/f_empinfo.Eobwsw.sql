create
    definer = root@`%` function f_empinfo(_id int unsigned) returns varchar(64)
BEGIN
	declare v_ret varchar(64) default '미등록 직원';
    select concat(e.ename, '(' , ifnull(d.dname, '발령 대기'), ')') into v_ret
      from Emp e left outer join Dept d on e.dept = d.id
	 where e.id = _id;
RETURN v_ret;
END;

